from fastapi import APIRouter, Depends
from model.meeting import Meeting
from typing import List
from datetime import date
from helper import verify_api_key
from bson import ObjectId

router = APIRouter()

# Temporärer In-Memory-Speicher (für Entwicklung)
MEETINGS_DB: List[Meeting] = []

@router.post("/meetings", dependencies=[Depends(verify_api_key)], tags=["Meeting"])
def create_meeting(meeting: Meeting):
    MEETINGS_DB.append(meeting)
    return {"message": "Meeting erstellt", "meeting": meeting}

@router.get("/meetings", dependencies=[Depends(verify_api_key)], tags=["Meeting"])
def list_meetings():
    return MEETINGS_DB

@router.get("/meetings/{meeting_id}", dependencies=[Depends(verify_api_key)], tags=["Meeting"])
def get_meeting(meeting_id: str):
    for meeting in MEETINGS_DB:
        if meeting.id == meeting_id:
            return meeting
    return {"error": "Meeting nicht gefunden"}
