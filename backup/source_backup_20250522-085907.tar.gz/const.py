import json

status_liste = ["✨ neu", "🚧 in Arbeit", "📦 laufend", "⏸️ wartet", "✅ abgeschlossen"]
prio_liste = ["🔴 kritisch", "🟠 hoch", "🟢 normal", "🔵 niedrig"]
mandanten_liste = ["HAM", "DHGS", "SCU", "HSSH", "Triagon", "IFI", "IUNWorld", "Alle"]